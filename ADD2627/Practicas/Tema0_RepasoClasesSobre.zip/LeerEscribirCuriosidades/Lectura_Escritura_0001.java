package LeerEscribirCuriosidades;
import java.io.*;
public class Lectura_Escritura_0001 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//creamos un canal de flujo de datos abierto para poder realizar una copia de los datos o del fichero que voy a abrir m
			// Copiando los bites del fichero
			
			FileInputStream archivo_lectura = new FileInputStream("C:/Users/fjesp/OneDrive/Escritorio/curso/Aprende_java_con_ejercicios.pdf");
			
			boolean final_ar=false;
			
			// vamos a leer bytes a bites 
			// mientras sea Cierto voy a gardar en una variable de tipo b
			while (!final_ar) {// cada vuelta del bucle leemos un bytes
			int bytes_entrada=archivo_lectura.read();
			//cuando llegamos al final del archivo este metodo nos devuelve -1
				if(bytes_entrada==-1)
					{
					final_ar=true;
					}
			System.out.println(bytes_entrada);
			
			}
			archivo_lectura.close();
			
		}catch(IOException e) {}
		
	}
// no representamos todos los bytes de la consola.
	// no es capaz de imprimir 70.000 lineas
	
}
