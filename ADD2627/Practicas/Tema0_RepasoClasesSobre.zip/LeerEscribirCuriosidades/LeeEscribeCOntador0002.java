


	package LeerEscribirCuriosidades;
	import java.io.*;
	public class LeeEscribeCOntador0002 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			int contador=0;
			
			// Dependiendo de la imagen seleccionada nos saldra un valor diferente para poder calcularlo usaremos
			/*Este codigo 
			 * 			try {
				//creamos un canal de flujo de datos abierto para poder realizar una copia de los datos o del fichero que voy a abrir m
				// Copiando los bites del fichero
				
				FileInputStream archivo_lectura = new FileInputStream("C:/Users/fjesp/OneDrive/Escritorio/exames/leon.jpg");
				
				boolean final_ar=false;
				
				// vamos a leer bytes a bites 
				// mientras sea Cierto voy a gardar en una variable de tipo b
				while (!final_ar) {// cada vuelta del bucle leemos un bytes
				int bytes_entrada=archivo_lectura.read();
				//cuando llegamos al final del archivo este metodo nos devuelve -1
				if(bytes_entrada==-1)
						{
						final_ar=true;
						}
				System.out.println(bytes_entrada);
				
				contador ++;
				
				}
				archivo_lectura.close();
				
			}catch(IOException e) {}
			System.out.println("El numero de lineas es "+contador);
			*/
			int datos_entrada[]= new int[55722];
			try {
				//creamos un canal de flujo de datos abierto para poder realizar una copia de los datos o del fichero que voy a abrir m
				// Copiando los bites del fichero
				
				FileInputStream archivo_lectura = new FileInputStream("C:/Users/fjesp/OneDrive/Escritorio/exames/leon.jpg");
				
				boolean final_ar=false;
				
				// vamos a leer bytes a bites 
				// mientras sea Cierto voy a gardar en una variable de tipo b
				while (!final_ar) {// cada vuelta del bucle leemos un bytes
				
					int bytes_entrada=archivo_lectura.read();
					
					// para no guardar el - 1 que es el valor de -1 cuando el numero d bytes es 0
					//sino guardariamos un -1 como ultimo dato en el archivo
					if (bytes_entrada!=-1) {
						datos_entrada[contador]=bytes_entrada;
					}
					//int bytes_entrada=archivo_lectura.read();
				//cuando llegamos al final del archivo este metodo nos devuelve -1
					else
						{
						final_ar=true;
						}
				System.out.println(datos_entrada[contador]);
				
				contador ++;
				
				}
				archivo_lectura.close();
				
			}catch(IOException e) {}
			System.out.println("El numero de lineas es "+contador);
			
		}
	// no representamos todos los bytes de la consola.
		// no es capaz de imprimir 70.000 lineas
		
	
}
