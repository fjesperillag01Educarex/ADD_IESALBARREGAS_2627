package Tema1Excpciones;

public class Excepciones_diversas {
	public static void main (String [] args) {
		//rellenar array con numero variados
		int nums [][] =new int[2][3];
		for (int i =0 ;i<2;i++)
			for(int j=0;j<3;j++) {
				nums[i][j]=i+j;
			}
		//realizar calculo paa cada posicion del array
		//se producen excepciones diversos tipos.
		for (int i=0;i<3;i++)
				for(int j=0;j<3;j++) {
					try {
						System.out.print("Segunda cifra 5* num["+i+"]["+j+"]: ");
						System.out.println(String.valueOf(5*(nums[i][j])/j));//.charAt(1));
					}catch(ArithmeticException e) {}
				}
	}

}