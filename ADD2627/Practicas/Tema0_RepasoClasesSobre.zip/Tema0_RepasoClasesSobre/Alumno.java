package Tema0_RepasoClasesSobre;

public class Alumno extends persona {

	String [] asignaturas;

	public Alumno() {
		super();
	}
	
	public Alumno(String [] asignaturas,String nombre,int edad) {
		super(nombre, edad);
		
		this.asignaturas=asignaturas;
		
	}
	public String[] getAsignaturas() {
		return asignaturas;
	}

	public void setAsignaturas(String[] asignaturas) {
		this.asignaturas = asignaturas;
	}
	
	
	
	
	
	
}
