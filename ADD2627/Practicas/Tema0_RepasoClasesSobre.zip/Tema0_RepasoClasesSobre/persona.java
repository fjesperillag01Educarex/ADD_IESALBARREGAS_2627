package Tema0_RepasoClasesSobre;

public class persona implements nombreA {

	private String nombre;
	private int edad;
	/////COntructores
	
	public persona() {}
	
	public persona (String nombre, int edad) {
		this.nombre=nombre;
		this.edad=edad;
	}
	
	//getes y setes
	public String getNombre() {		return nombre;	}

	

	public void setNombre(String nombre) {	this.nombre = nombre;}

	public int getEdad() {	return edad;}

	public void setEdad(int edad) {	this.edad = edad;}


//funciones ///
	@Override
	public void mostrar() {
		System.out.println("Estoy en mostrar de persona");
		
	}
	@Override
	public String toString() {
		return "persona [nombre=" + nombre + ", edad=" + edad + "]";
	}

	public void MostrarAsignatura() {
		// TODO Auto-generated method stub
		
	}
}
