package Tema0_RepasoClasesSobre;

public class AlumnoDelegado extends Alumno {

	String CursoDelegado ;
	
	public AlumnoDelegado() {
		// TODO Auto-generated constructor stub
	}
	
	public AlumnoDelegado (String curso, String []asignaturas,String nombre,int edad ) {
		super(asignaturas,nombre,edad);
		this.CursoDelegado=curso;
	}
		
	//https://docs.oracle.com/javase/7/docs/api/java/util/Stack.html
}

