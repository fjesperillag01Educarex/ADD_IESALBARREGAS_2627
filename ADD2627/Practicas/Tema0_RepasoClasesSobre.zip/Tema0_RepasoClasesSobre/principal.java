package Tema0_RepasoClasesSobre;

public class principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Profesor p1=new Profesor("fernando","profesor",33);
		
		p1.mostrar();
		System.out.println(p1.toString());
		
		
		
	}

}
