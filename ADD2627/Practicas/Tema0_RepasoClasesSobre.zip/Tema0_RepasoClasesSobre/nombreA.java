package Tema0_RepasoClasesSobre;

public interface nombreA {

	public void mostrar();

	public void MostrarAsignatura();
}
