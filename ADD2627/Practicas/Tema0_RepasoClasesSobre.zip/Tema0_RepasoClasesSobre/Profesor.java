package Tema0_RepasoClasesSobre;

public class Profesor extends persona implements nombreA{
private String Asignatura;
///constructor

public Profesor() {}

public Profesor(String Asignatura,String nombre,int edad) {
	super(nombre,edad);
	this.Asignatura=Asignatura;
	//super(nombre,edad); ha de ser llamado el primero
	
	
}



public String getAsignatura() {
	return Asignatura;
}

public void setAsignatura(String asignatura) {
	Asignatura = asignatura;
}

@Override
public void MostrarAsignatura() {
	// TODO Auto-generated method stub
	
}

public void mostrar() {
	System.out.println("Estoy en mostrar de Profesor");
}

}
