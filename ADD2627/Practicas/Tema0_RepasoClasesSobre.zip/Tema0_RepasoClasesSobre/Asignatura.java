package Tema0_RepasoClasesSobre;

public interface Asignatura {

	
	public void MostrarAsignatura();
}
