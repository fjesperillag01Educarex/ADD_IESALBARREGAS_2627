package Tema1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Crear_fichero_0013Unicode {

    public static void main(String[] args) {
        // El nombre del archivo que se va a crear
        String nombreArchivo = "archivo_seguro.txt";
        
        // El texto original con caracteres especiales, acentos y eñes
        String textoOriginal = "¡Hola del año 2026! Esta es una prueba con "
                + "acentos (á, é, í, ó, ú), mayúsculas (Á, É, Í, Ó, Ú) y "
                + "caracteres especiales como la eñe (ñ, Ñ) y apertura (¿).";

        // Convertimos el texto a su representación estricta en escapes Unicode
        String textoCodificado = convertirAUnicodeEscape(textoOriginal);

        // Guardamos el texto codificado en el fichero
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(nombreArchivo))) {
            escritor.write(textoCodificado);
            System.out.println(" Fichero guardado con \u00e9xito en: " + nombreArchivo);
            System.out.println("\n--- Contenido real escrito en el archivo ---");
            System.out.println(textoCodificado);
        } catch (IOException e) {
            System.err.println("Error al guardar el archivo: " + e.getMessage());
        }
    }

    
     //Convierte cualquier carácter no ASCII en su escape Unicode formato 
    ///// Junta la barra y la u "\ uXXXX"
  
     //Mantiene los caracteres ASCII estandar intactos para que el archivo sea legible.
     
    public static String convertirAUnicodeEscape(String texto) {
        StringBuilder sb = new StringBuilder();
        for (char c : texto.toCharArray()) {
            // Los caracteres ASCII estándar van del 32 al 126 (letras, números, espacios)
            // También mantenemos los saltos de línea (\n = 10) y retornos (\r = 13)
            if ((c >= 32 && c <= 126) || c == 10 || c == 13) {
                sb.append(c);
            } else {
                // Convierte a formato hexadecimal de 4 dígitos (ej: \u00f1)
                sb.append(String.format("\\u%04x", (int) c));
            }
        }
        return sb.toString();
    }
}