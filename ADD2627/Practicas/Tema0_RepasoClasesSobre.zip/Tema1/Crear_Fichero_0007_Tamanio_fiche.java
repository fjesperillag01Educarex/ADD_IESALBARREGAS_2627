package Tema1;
/// Crear un programa que inserte en un fichero 1000 veces Hola
// muestra el resultado de escribir en el fichero 10000 veces hola
// crea un fichero en el que insertes hola\n 10000
// muestra el la longitud de ambos archivos.
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Crear_Fichero_0007_Tamanio_fiche {
    public static void main(String[] args) {
        // Nombre del archivo que se va a crear
        String nombreArchivo = "saludo.txt";
        
        // 1. Insertar la palabra "hola" en el fichero
        try (FileWriter escritor = new FileWriter(nombreArchivo)) {
            escritor.write("hola");
            System.out.println("Se ha escrito la palabra 'hola' en el archivo.");
        } catch (IOException e) {
            System.out.println("Ocurrió un error al escribir en el archivo: " + e.getMessage());
        }

        // 2. Obtener y mostrar la longitud del fichero
        File archivo = new File(nombreArchivo);
        if (archivo.exists()) {
            long longitud = archivo.length();
            System.out.println("La longitud del archivo '" + nombreArchivo + "' es: " + longitud + " bytes.");
        } else {
            System.out.println("El archivo no existe.");
        }
    }
}