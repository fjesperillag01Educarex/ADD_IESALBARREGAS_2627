package Tema1;
/*
 * Comprueba si un determinado fichero que has creado, nuevo utilizando Crear_Fichero0001
 * Es un fichero utilizando la funcion isFile()
 * */
public class Crear_Fichero_0004_isFile {

}
