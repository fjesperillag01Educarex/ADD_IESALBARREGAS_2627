package Tema1;
/*
 * A) Escribir el emoji directamente (recomendado si tu archivo está en UTF-8) 
 * System.err.println(" ❌ No se pudo crear 'miDirectorio'"); 
 * System.out.println(" ✅ Directorio creado"); 
 * System.out.println(" ℹ Revisa los permisos"); 
 * System.out.println(" 📁 Ruta: " + ruta); */

import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

public class Crear_Fichero_0011_GenerarMensajeEmoji {
    public static void main(String[] args) {
        // Asegura que la consola imprima en UTF-8 (útil en entornos como Windows)
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));

        System.out.println("=== Mensajes con Emojis en Java ===");

        // Método 1: Copiando y pegando el emoji directamente en el texto
        System.out.println("🚀 ¡Operación completada con éxito!");
        System.out.println("💡 Recuerda revisar la documentación antes de programar.");
        System.out.println("🎉 ¡Felicidades por tu nuevo proyecto!");

        // Método 2: Usando secuencias de escape Unicode (Surrogate Pairs)
        // El emoji de la cara sonriente (😀) es U+1F600, en Java se escribe: \uD83D\uDE00
        System.out.println("\n--- Usando códigos Unicode ---");
        System.out.println("Hola mundo \uD83D\uDE00"); // 😀
        System.out.println("Código correcto \u2705");  // ✅
    }
}