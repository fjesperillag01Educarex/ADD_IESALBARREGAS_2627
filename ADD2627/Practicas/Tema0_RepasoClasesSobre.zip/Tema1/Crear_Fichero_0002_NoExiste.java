package Tema1;


	
	import java.io.File; 
	import java.io.FileNotFoundException; 
	import java.util.Scanner; 
	public class Crear_Fichero_0002_NoExiste { public static void main(String[] args) { 
		try { 
			File fichero = new File("noexiste.txt"); 
			Scanner sc = new Scanner(fichero); 
			while (sc.hasNextLine()) { 
				System.out.println(sc.nextLine()); } 
				sc.close(); 
			} 
		catch (FileNotFoundException e) { 
			System.out.println("El fichero no fue encontrado."); 
			} 
	} 
	}

