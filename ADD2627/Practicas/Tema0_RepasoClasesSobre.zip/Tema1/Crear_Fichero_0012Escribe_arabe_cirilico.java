package Tema1;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

public class Crear_Fichero_0012Escribe_arabe_cirilico {
    public static void main(String[] args) {
        // Ruta del archivo donde se guardará el texto
        String rutaArchivo = "texto_arabe.txt";
        
        // Texto en árabe ("Hola mundo" y "Bienvenidos")
        String textoArabe = "مرحبا بالعالم\nأهلا وسهلا بك";

        // Uso de try-with-resources para asegurar el cierre automático del archivo
        try (BufferedWriter escritor = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(rutaArchivo), StandardCharsets.UTF_8))) {
            
            escritor.write(textoArabe);
            System.out.println("El archivo se ha guardado correctamente en UTF-8.");
            
        } catch (IOException e) {
            System.err.println("Ocurrió un error al guardar el archivo: " + e.getMessage());
        }
    }
}