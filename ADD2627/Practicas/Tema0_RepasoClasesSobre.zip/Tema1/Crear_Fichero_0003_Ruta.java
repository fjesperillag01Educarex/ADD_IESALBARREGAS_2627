package Tema1;

import java.io.File; 
public class Crear_Fichero_0003_Ruta { public static void main(String[] args) 
{ File fichero = new File("datos.txt"); 
System.out.println("Nombre: " + fichero.getName()); 
System.out.println("Ruta absoluta: " + fichero.getAbsolutePath()); 
System.out.println("Existe?: " + fichero.exists()); 
} 
}