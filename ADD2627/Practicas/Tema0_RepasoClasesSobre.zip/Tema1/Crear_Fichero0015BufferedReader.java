package Tema1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Crear_Fichero0015BufferedReader {
    public static void main(String[] args) {
        // Creamos el BufferedReader conectado a la entrada estándar (teclado)
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Escribe tu nombre: ");
            String nombre = reader.readLine(); // Lee toda la línea escrita

            System.out.print("Escribe tu edad: ");
            String entradaEdad = reader.readLine();
            int edad = Integer.parseInt(entradaEdad); // Convertimos el texto a número

            System.out.println("\n¡Hola, " + nombre + "!");
            System.out.println("Tienes " + edad + " años.");

        } catch (IOException e) {
            System.out.println("Ocurrió un error al leer el dato: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Por favor, introduce un número válido para la edad.");
        }
    }
}