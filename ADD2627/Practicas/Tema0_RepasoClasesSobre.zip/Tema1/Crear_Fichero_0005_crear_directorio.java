package Tema1;
/*
 * Crea un una carpeta en un determinado directorio 
 * */
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class Crear_Fichero_0005_crear_directorio {
    public static void main(String[] args) {
    	//C:\Users\fjesp_h7ggk10\eclipse-workspace\entorno_Desarrollo\AD2627Albarregas\AD_26_27_Albarregas\src\Tema1
    	Path ruta = Paths.get("C:/Users/fjesp_h7ggk10/eclipse-workspace/entorno_Desarrollo/AD2627Albarregas/AD_26_27_Albarregas/src/Tema1/midam2a");
        //Path ruta = Paths.get("c:/temp/miCarpetaNIO");
        
        try {
            // Crea el directorio y los padres si faltan
            Files.createDirectories(ruta);
            System.out.println("Directorio creado correctamente.");
        } catch (IOException e) {
            System.out.println("Error al crear el directorio: " + e.getMessage());
        }
    }
}


/////////////Opcion 1 Antiguo
/*
 * import java.io.File;

public class CrearDirectorio {
    public static void main(String[] args) {
        // Define la ruta de la carpeta
        File directorio = new File("c:/temp/miCarpeta"); // O usa "miCarpeta" para ruta relativa
        
        // Crea el directorio si no existe
        if (!directorio.exists()) {
            boolean resultado = directorio.mkdirs(); // mkdirs() crea carpetas principales y secundarias
            if (resultado) {
                System.out.println("Directorio creado con éxito.");
            } else {
                System.out.println("No se pudo crear el directorio.");
            }
        } else {
            System.out.println("El directorio ya existe.");
        }
    }
}
 */
