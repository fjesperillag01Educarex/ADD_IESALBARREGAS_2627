package Tema1;
/* En este ejercicio se creeara un archivo cullo nombre será no Existe.
se guardará en la ruta en la que tengas creado el proyecto
En mi caso C:\Users\fjesp_h7ggk10\eclipse-workspace\entorno_Desarrollo\AD2627Albarregas
//C:\Users\fjesp\eclipse-workspace\(AD) Acceso a datos
*/
import java.io.File; import java.io.IOException; 
public class Crear_Fichero_0001 { public static void main(String[] args) 
{ 
	try { File fichero = new File("noexiste.txt"); 
		if (fichero.createNewFile()) 
			{ System.out.println("Fichero creado: " + fichero.getName());
			} 
		else { 
			System.out.println("El fichero ya existe."); } 
		} catch (IOException e) 
			{ System.out.println("Error al crear el fichero: " + e.getMessage()); 
			} 
	} 
}