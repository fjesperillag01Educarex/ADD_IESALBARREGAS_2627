package Tema1;

import java.io.File;

public class Crear_fichero_0010_ListarDirectorios {
    public static void main(String[] args) {
        // Define aquí tu ruta absoluta (ejemplo para Windows o Linux/Mac)
        String rutaAbsoluta = "C:\\Windows"; // Cambia esta ruta por la que necesites
        
        // Crear el objeto File con la ruta absoluta
        File directorio = new File(rutaAbsoluta);
        
        // Comprobar si existe y si es un directorio
        if (directorio.exists() && directorio.isDirectory()) {
            System.out.println("Contenido de la ruta: " + rutaAbsoluta);
            
            // Obtener todos los archivos y carpetas dentro de la ruta
            File[] archivos = directorio.listFiles();
            
            if (archivos != null) {
                for (File archivo : archivos) {
                    // Si solo quieres mostrar los que son directorios (carpetas):
                    if (archivo.isDirectory()) {
                        System.out.println("[CARPETA] " + archivo.getName());
                    } else {
                        // Comentar o borrar este 'else' si no quieres ver los ficheros
                        System.out.println("[ARCHIVO] " + archivo.getName());
                    }
                }
            }
        } else {
            System.out.println("La ruta especificada no existe o no es un directorio válido.");
        }
    }
}