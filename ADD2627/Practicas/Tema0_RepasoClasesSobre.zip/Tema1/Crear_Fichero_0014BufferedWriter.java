package Tema1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Crear_Fichero_0014BufferedWriter {
    public static void main(String[] args) {
        // Nombre del archivo que vamos a crear
        String nombreArchivo = "salida.txt";

        // Usamos try-with-resources para cerrar el BufferedWriter automáticamente
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivo))) {
            
            bw.write("¡Hola! Este es el uso de BufferedWriter en Java.");
            bw.newLine(); // Inserta un salto de línea compatible con el sistema operativo
            bw.write("Escribir con un búfer es más eficiente porque reduce los accesos al disco.");
            bw.newLine();
            bw.write("Fin del archivo.");

            System.out.println("¡Archivo creado y escrito con éxito!");

        } catch (IOException e) {
            System.out.println("Ocurrió un error al escribir el archivo: " + e.getMessage());
        }
    }
}