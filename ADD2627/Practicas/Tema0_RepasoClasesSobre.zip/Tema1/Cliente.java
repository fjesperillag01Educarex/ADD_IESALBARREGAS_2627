/*
package Tema1t javax.persistence.*;

@Entity
@Table (name="cliente")
public class Cliente {

@Column (name="nombre")
private String nombre;

@Column (name="apellidos")
private String apellidos;

@Column (name="direccion")
private String direccion;
@Id 
@Generated(strategy=GenerationType.IDENTITY)
@Column(name="id")
private int id;



public Cliente() {}

public Cliente(String nombre,String apellidos,String direccion) {
	this.nombre=nombre;
	this.apellidos=apellidos;
	this.direccion=direccion;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public String getApellidos() {
	return apellidos;
}

public void setApellidos(String apellidos) {
	this.apellidos = apellidos;
}

public String getDireccion() {
	return direccion;
}

public void setDireccion(String direccion) {
	this.direccion = direccion;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

@Override
public String toString() {
	return id+"Nombre "+nombre+" apellidos "+apellidos+" direccion "+direccion;
	
}





}
*/
