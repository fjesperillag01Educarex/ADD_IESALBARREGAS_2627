package Tema1;

import java.io.File;

public class Crear_Fichero_0008BorrarFichero {
    public static void main(String[] args) {
        // Define la ruta absoluta al archivo
        String rutaAbsoluta = "C:\\carpeta1\\ejemplo1.txt"; // En Windows
        // O usa "/home/usuario/carpeta1/ejemplo1.txt" para Linux/Mac

        File archivo = new File(rutaAbsoluta);

        // Intenta borrar el archivo
        if (archivo.delete()) {
            System.out.println("El archivo se borró correctamente.");
        } else {
            System.out.println("No se pudo borrar el archivo (quizás no existe).");
        }
    }
}