package Tema1;

import java.io.File;

public class Crear_Fichero_0009_ListarFichero {
    public static void main(String[] args) {
        // Cambia esta ruta por la de tu directorio (ej. "C:\\mi_carpeta" o "/home/usuario/carpeta")
        String rutaDirectorio = "./"; 
        
        File directorio = new File(rutaDirectorio);
        
        // Comprobamos si existe y si es una carpeta
        if (directorio.exists() && directorio.isDirectory()) {
            System.out.println("Buscando archivos .java en: " + directorio.getAbsolutePath());
            
            // Obtenemos todos los archivos y carpetas dentro del directorio
            File[] archivos = directorio.listFiles();
            
            if (archivos != null) {
                int contador = 0;
                for (File archivo : archivos) {
                    // Verificamos que sea un archivo (no otra carpeta) y que termine en .java
                    if (archivo.isFile() && archivo.getName().toLowerCase().endsWith(".java")) {
                        System.out.println("- " + archivo.getName());
                        contador++;
                    }
                }
                System.out.println("\nTotal de archivos .java encontrados: " + contador);
            }
        } else {
            System.out.println("La ruta proporcionada no es un directorio válido o no existe.");
        }
    }
}