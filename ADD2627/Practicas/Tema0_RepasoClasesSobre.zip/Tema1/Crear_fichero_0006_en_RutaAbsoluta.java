package Tema1;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class Crear_fichero_0006_en_RutaAbsoluta {
    public static void main(String[] args) {
        // Obtiene la ruta absoluta
        Path rutaAbsoluta = Paths.get("C:/archivos/mi-fichero.txt");
        
        try {
            // Crea el fichero físicamente
            Files.createFile(rutaAbsoluta);
            System.out.println("¡Fichero creado correctamente con NIO!");
        } catch (IOException e) {
            System.out.println("El fichero ya existe o hubo un error: " + e.getMessage());
        }
    }
}